﻿
using System;
using Wisej.Web;

namespace AppWeb1
{
    public partial class Window1 : Form
    {
        public Window1()
        {
            InitializeComponent();
        }
    }
}
