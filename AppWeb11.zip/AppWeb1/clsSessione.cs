﻿namespace AppWeb1
{
    public class clsSessione
    {
        public string Utente = "";
        public bool Autenticato = false;
    }
}
